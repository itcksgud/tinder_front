// src/api/index.ts
import axios from 'axios';

const BASE_URL = __DEV__
  ? 'http://localhost:5000/api'
  : 'https://도메인.컴/api';

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

export default api;

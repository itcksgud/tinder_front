// src/navigation/AppStack.tsx
import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import Explore from '../screens/app/Explore';
import Matches from '../screens/app/Matches';
import Messages from '../screens/app/Messages';
import Profile from '../screens/app/Profile'; // 폴더 이동 후 경로 수정

export type AppTabParamList = {
  Explore: undefined;
  Home: undefined;
  Matches: undefined;
  Messages: undefined;
  Profile: undefined;
};

const Tab = createBottomTabNavigator<AppTabParamList>();

export default function AppStack() {
  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarIcon: ({ color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;
          switch (route.name) {
            case 'Explore': iconName = 'search'; break;
            case 'Home': iconName = 'home'; break;
            case 'Matches': iconName = 'heart'; break;
            case 'Messages': iconName = 'chatbubble'; break;
            case 'Profile': iconName = 'person'; break;
            default: iconName = 'help';
          }
          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Explore" component={Explore} />
      <Tab.Screen name="Matches" component={Matches} />
      <Tab.Screen name="Messages" component={Messages} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
}

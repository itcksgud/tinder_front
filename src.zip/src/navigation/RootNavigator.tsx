// src/navigation/RootNavigator.tsx
import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AuthStack from './AuthStack';
import AppStack from './AppStack';
import { useAuth } from '../context/AuthContext';
import { View, ActivityIndicator, Alert } from 'react-native';

export default function RootNavigator() {
  const { auth, loading } = useAuth();

  useEffect(() => {
    if (auth && !auth.user.isVerified) {
      Alert.alert(
        '이메일 인증 필요',
        '이메일 인증을 완료해 주세요.',
        [{ text: '확인' }],
        { cancelable: false }
      );
    }
  }, [auth]);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      {!auth
        ? <AuthStack />
        : auth.user.isVerified
          ? <AppStack />
          : <AuthStack />
      }
    </NavigationContainer>
  );
}

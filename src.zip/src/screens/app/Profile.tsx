// src/screens/app/Profile.tsx
import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function Profile() {
  // TODO: API에서 유저 정보 불러와서 보여주기
  return (
    <View style={styles.container}>
      <Image
        source={{ uri: 'https://placekitten.com/200/200' }}
        style={styles.avatar}
      />
      <Text style={styles.name}>홍길동</Text>
      <Text style={styles.bio}>안녕하세요! 반가워요 😊</Text>
      <TouchableOpacity style={styles.editButton}>
        <Text style={styles.editButtonText}>프로필 편집</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', paddingTop: 40 },
  avatar: { width: 140, height: 140, borderRadius: 70, marginBottom: 20 },
  name: { fontSize: 24, fontWeight: '600', marginBottom: 8 },
  bio: { fontSize: 16, color: '#666', marginBottom: 24, paddingHorizontal: 16, textAlign: 'center' },
  editButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    backgroundColor: '#FF5864',
    borderRadius: 24,
  },
  editButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

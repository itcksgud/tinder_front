// src/screens/auth/VerifyEmail.tsx
import React from 'react';
import { View, Text, Button, Alert } from 'react-native';
import api from '../../api';
import { useAuth } from '../../context/AuthContext';

export default function VerifyEmail() {
  const { signOut } = useAuth();

  const resend = async () => {
    await api.post('/auth/resend-verification');
    Alert.alert('인증 메일이 재전송되었습니다.');
  };

  return (
    <View style={{ flex:1, justifyContent:'center', padding:24 }}>
      <Text>이메일 인증이 필요합니다.</Text>
      <Button title="인증 메일 재전송" onPress={resend} />
      <Button title="로그아웃" onPress={signOut} color="red" />
    </View>
  );
}

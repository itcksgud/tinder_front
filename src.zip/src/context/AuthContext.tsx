import React, {
  createContext,
  useState,
  useEffect,
  useContext,
  useCallback,
  ReactNode,
} from 'react';
import * as SecureStore from 'expo-secure-store';
import api from '../api';

type AuthState = {
  accessToken: string;
  user: { id: string; email: string; isVerified: boolean; username: string };
};
type AuthContextType = {
  auth: AuthState | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [auth, setAuth] = useState<AuthState | null>(null);
  const [loading, setLoading] = useState(true);

    useEffect(() => {
    const initAuth = async () => {
        const token = await SecureStore.getItemAsync('accessToken');
        if (token) {
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
        const res = await api.get('/auth/me'); // 사용자 정보 확인
        const user = res.data.user;
        setAuth({
            accessToken: token,
            user:user
        });
        }
        setLoading(false);
    };
    initAuth();
    }, []);

  const signIn = useCallback(async (email:string, password:string) => {
    const res = await api.post('/auth/login', { email, password });
    const { accessToken, user } = res.data;
    await SecureStore.setItemAsync('accessToken', accessToken);
    api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
    setAuth({ accessToken, user });
  }, []);

  const signOut = useCallback(async () => {
    await SecureStore.deleteItemAsync('accessToken');
    delete api.defaults.headers.common['Authorization'];
    setAuth(null);
  }, []);

  return (
    <AuthContext.Provider value={{ auth, loading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
};
